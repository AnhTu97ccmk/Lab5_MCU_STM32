/*
 * uartcom.h
 *
 *  Created on: Nov 19, 2026
 *      Author: pc
 */

#ifndef INC_UARTCOM_H_
#define INC_UARTCOM_H_

#include <stdint.h>
#include "main.h"

#define OK_TIMEOUT_MS   3000    /* time to wait for !OK# before sending again */

void uart_communication_fsm(void);      /* call in every iteration of while(1) */

#endif /* INC_UARTCOM_H_ */
