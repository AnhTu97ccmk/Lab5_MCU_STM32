/*
 * commandparser.h
 *
 *  Created on: Nov 19, 2026
 *      Author: pc
 */

#ifndef INC_COMMANDPARSER_H_
#define INC_COMMANDPARSER_H_

#include <stdint.h>
#include "main.h"

#define MAX_BUFFER_SIZE   32    /* size of the receive ring buffer          */

/* values of command_data */
#define CMD_NONE          0
#define CMD_RST           1     /* !RST#  : terminal asks for the sensor data */
#define CMD_OK            2     /* !OK#   : terminal acknowledges the packet */

extern uint8_t temp;                    /* the byte being received by the UART   */
extern uint8_t command_flag;            /* 1 = a new complete command is ready   */
extern uint8_t command_data;            /* which command: CMD_RST or CMD_OK      */

void command_parser_init(void);         /* call once, before the main loop       */
void command_parser_fsm(void);          /* call in every iteration of while(1)   */

#endif /* INC_COMMAND_PARSER_H_ */


