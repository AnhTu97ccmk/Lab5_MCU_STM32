/*
 * commandparser.c
 *
 *  Created on: Nov 19, 2026
 *      Author: pc
 */
#include "commandparser.h"
#include <string.h>

extern UART_HandleTypeDef huart2;

#define CMD_MAX_LEN   8         /* longest command text + 1 ('\0')            */

/* ---------- receive ring buffer (written by ISR, read by main loop) ---------- */
uint8_t temp = 0;
static volatile uint8_t buffer[MAX_BUFFER_SIZE];
static volatile uint8_t buffer_head = 0;    /* next position written by the ISR  */
static volatile uint8_t buffer_tail = 0;    /* next position read by the parser  */

/* ---------- outputs of the parser ---------- */
uint8_t command_flag = 0;
uint8_t command_data = CMD_NONE;

/* ---------- parser FSM ---------- */
typedef enum {
    PARSER_WAIT_START,      /* waiting for '!'                       */
    PARSER_READ_CMD         /* collecting characters until '#'       */
} ParserState;

static ParserState parserState = PARSER_WAIT_START;
static char    cmdText[CMD_MAX_LEN];
static uint8_t cmdLen = 0;

void command_parser_init(void)
{
    buffer_head = 0;
    buffer_tail = 0;
    command_flag = 0;
    command_data = CMD_NONE;
    parserState = PARSER_WAIT_START;
    HAL_UART_Receive_IT(&huart2, &temp, 1);     /* start receiving 1 byte */
    //HAL_UART_Transmit(&huart2, (uint8_t *)"hello\r\n", 7, 100);
}


/* Called by HAL when 1 byte has been received. Must be SHORT. */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
    	 //HAL_UART_Transmit (& huart2 , &temp , 1, 50);
        uint8_t next = (uint8_t)((buffer_head + 1) % MAX_BUFFER_SIZE);
        if (next != buffer_tail) {              /* drop the byte if the buffer is full */
            buffer[buffer_head] = temp;
            buffer_head = next;
        }
        HAL_UART_Receive_IT(&huart2, &temp, 1); /* arm the interrupt again */
    }
}

/* If a UART error (e.g. overrun) stops the reception, start it again */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        HAL_UART_Receive_IT(&huart2, &temp, 1);
    }
}

static void finish_command(void)
{
    cmdText[cmdLen] = '\0';
    if (strcmp(cmdText, "RST") == 0) {
        command_data = CMD_RST;
        command_flag = 1;
    } else if (strcmp(cmdText, "OK") == 0) {
        command_data = CMD_OK;
        command_flag = 1;
    }
    /* any other text is an unknown command: ignored */
}

void command_parser_fsm(void)
{
    while (buffer_tail != buffer_head) {        /* process every received byte */
        uint8_t ch = buffer[buffer_tail];
        buffer_tail = (uint8_t)((buffer_tail + 1) % MAX_BUFFER_SIZE);

        switch (parserState) {
        case PARSER_WAIT_START:
            if (ch == '!') {
                cmdLen = 0;
                parserState = PARSER_READ_CMD;
            }
            break;

        case PARSER_READ_CMD:
            if (ch == '#') {                    /* end of the command */
                finish_command();
                parserState = PARSER_WAIT_START;
            } else if (ch == '!') {             /* a new frame starts: drop the old one */
                cmdLen = 0;
            } else if (cmdLen < CMD_MAX_LEN - 1) {
                cmdText[cmdLen++] = (char)ch;
            } else {                            /* too long: not a valid command */
                parserState = PARSER_WAIT_START;
            }
            break;
        }
    }
}

