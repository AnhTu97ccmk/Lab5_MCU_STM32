/*
 * uartcom.c
 *
 *  Created on: Nov 19, 2026
 *      Author: pc
 */

#include "uartcom.h"
#include "commandparser.h"
#include <stdio.h>

extern UART_HandleTypeDef huart2;
extern ADC_HandleTypeDef  hadc1;

typedef enum {
    UART_IDLE,          /* waiting for !RST#                          */
    UART_WAIT_OK        /* packet sent, waiting for !OK# (3 s timeout) */
} UartState;

static UartState uartState = UART_IDLE;
static uint32_t  ADC_value = 0;         /* value of the last packet (kept for re-sending) */
static uint32_t  timeoutStart = 0;      /* HAL_GetTick() when the packet was last sent    */

static uint32_t read_adc(void)
{
    uint32_t v;
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 10);
    v = HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);
    return v;
}

static void send_packet(void)
{
    char str[24];
    int len = snprintf(str, sizeof(str), "!ADC=%lu#\r\n", (unsigned long)ADC_value);
    HAL_UART_Transmit(&huart2, (uint8_t *)str, (uint16_t)len, 1000);
    timeoutStart = HAL_GetTick();       /* (re)start the 3 s timeout */
}

static void new_request(void)
{
    ADC_value = read_adc();             /* read a NEW value only for a NEW request */
    send_packet();
    uartState = UART_WAIT_OK;
}

void uart_communication_fsm(void)
{
    uint8_t cmd = CMD_NONE;

    if (command_flag == 1) {            /* take (and clear) the command from the parser */
        cmd = command_data;
        command_flag = 0;
    }

    switch (uartState) {
    case UART_IDLE:
        if (cmd == CMD_RST) {
            new_request();
        }
        /* !OK# without a request is ignored */
        break;

    case UART_WAIT_OK:
        if (cmd == CMD_OK) {
            uartState = UART_IDLE;              /* communication finished */
        } else if (cmd == CMD_RST) {
            new_request();                      /* the terminal asks again */
        } else if (HAL_GetTick() - timeoutStart >= OK_TIMEOUT_MS) {
            send_packet();                      /* timeout: send the SAME packet again */
        }
        break;
    }
}
